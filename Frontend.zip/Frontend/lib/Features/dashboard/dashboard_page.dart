import 'package:flutter/material.dart';
import 'package:safecommuteai/Features/dashboard/widgets/sidebar.dart';
import 'package:safecommuteai/Features/dashboard/widgets/header.dart';
import 'package:safecommuteai/Features/dashboard/widgets/violations_table.dart';
import 'package:safecommuteai/Features/dashboard/widgets/overview_dashboard.dart';

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  int _selectedIndex = 0;
  String _searchQuery = '';
  final FocusNode _searchFocusNode = FocusNode();

  void _onMenuItemSelected(int index) {
    setState(() {
      _selectedIndex = index;
      if (_selectedIndex == 0) {
        _searchQuery = '';
      }
    });
  }

  void _onSearch(String query) {
    if (_selectedIndex != 1) return;
    setState(() {
      _searchQuery = query;
    });
  }

  void _jumpToViolationsAndFocusSearch() {
    setState(() {
      _selectedIndex = 1;
    });
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _searchFocusNode.requestFocus();
    });
  }

  @override
  void dispose() {
    _searchFocusNode.dispose();
    super.dispose();
  }

  static const double _narrowBreakpoint = 600;

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final useDrawer = width < _narrowBreakpoint;

    final mainContent = Column(
      children: [
        DashboardHeader(
          onSearch: _onSearch,
          focusNode: _searchFocusNode,
          readOnlySearch: _selectedIndex == 0,
          onSearchTap: _jumpToViolationsAndFocusSearch,
          onMenuTap: useDrawer ? _openDrawer : null,
        ),
        Expanded(child: _buildContent()),
      ],
    );

    if (useDrawer) {
      return Scaffold(
        backgroundColor: const Color(0xFFF8F9FA),
        key: _scaffoldKey,
        drawer: Drawer(
          child: Sidebar(
            selectedIndex: _selectedIndex,
            onItemSelected: (index) {
              _onMenuItemSelected(index);
              Navigator.of(context).pop();
            },
          ),
        ),
        body: mainContent,
      );
    }

    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FA),
      body: Row(
        children: [
          Sidebar(
            selectedIndex: _selectedIndex,
            onItemSelected: _onMenuItemSelected,
          ),
          Expanded(child: mainContent),
        ],
      ),
    );
  }

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  void _openDrawer() {
    _scaffoldKey.currentState?.openDrawer();
  }

  Widget _buildContent() {
    switch (_selectedIndex) {
      case 0:
        return const DashboardOverviewContent();
      case 1:
        return ViolationsContent(searchQuery: _searchQuery);
      default:
        return const DashboardOverviewContent();
    }
  }
}

class ViolationsContent extends StatelessWidget {
  final String searchQuery;

  const ViolationsContent({
    super.key,
    this.searchQuery = '',
  });

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final padding = w < 400 ? 12.0 : (w < 600 ? 16.0 : 24.0);
    return Padding(
      padding: EdgeInsets.all(padding),
      child: SizedBox(
        width: double.infinity,
        child: ViolationsTable(searchQuery: searchQuery),
      ),
    );
  }
}
