import 'package:flutter/material.dart';

class Sidebar extends StatelessWidget {
  final int selectedIndex;
  final Function(int) onItemSelected;

  const Sidebar({
    super.key,
    required this.selectedIndex,
    required this.onItemSelected,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 240,
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(
          right: BorderSide(
            color: Color(0xFFE5E7EB),
            width: 1,
          ),
        ),
      ),
      child: Column(
        children: [
          // Logo section
          _buildLogo(),
          const SizedBox(height: 32),
          // Menu items
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Column(
                children: [
                  _MenuItem(
                    icon: Icons.dashboard_outlined,
                    activeIcon: Icons.dashboard,
                    label: 'Dashboard',
                    isSelected: selectedIndex == 0,
                    onTap: () => onItemSelected(0),
                  ),
                  const SizedBox(height: 8),
                  _MenuItem(
                    icon: Icons.warning_amber_outlined,
                    activeIcon: Icons.warning_amber,
                    label: 'Violations',
                    isSelected: selectedIndex == 1,
                    onTap: () => onItemSelected(1),
                  ),
                ],
              ),
            ),
          ),
          // Logout button at bottom
          Padding(
            padding: const EdgeInsets.all(16),
            child: _MenuItem(
              icon: Icons.logout_outlined,
              activeIcon: Icons.logout,
              label: 'Logout',
              isSelected: false,
              onTap: () {
                // Handle logout
                Navigator.of(context).pushReplacementNamed('/login');
              },
              isLogout: true,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLogo() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
      child: Row(
        children: [
          // Logo icon
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Color(0xFF00D26A),
                  Color(0xFF00B85C),
                ],
              ),
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Icon(
              Icons.commute_rounded,
              color: Colors.white,
              size: 22,
            ),
          ),
          const SizedBox(width: 12),
          // Logo text
          const Text(
            'SafeCommute',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Color(0xFF1F2937),
              letterSpacing: 0.3,
            ),
          ),
        ],
      ),
    );
  }
}

class _MenuItem extends StatefulWidget {
  final IconData icon;
  final IconData activeIcon;
  final String label;
  final bool isSelected;
  final VoidCallback onTap;
  final bool isLogout;

  const _MenuItem({
    required this.icon,
    required this.activeIcon,
    required this.label,
    required this.isSelected,
    required this.onTap,
    this.isLogout = false,
  });

  @override
  State<_MenuItem> createState() => _MenuItemState();
}

class _MenuItemState extends State<_MenuItem> {
  bool _isHovered = false;

  @override
  Widget build(BuildContext context) {
    final isActive = widget.isSelected && !widget.isLogout;
    final primaryColor = const Color(0xFF00D26A);
    final logoutColor = const Color(0xFFEF4444);

    // Determine background color based on state
    Color bgColor;
    if (isActive) {
      bgColor = primaryColor.withOpacity(0.1);
    } else if (_isHovered) {
      bgColor = widget.isLogout 
          ? logoutColor.withOpacity(0.08) 
          : primaryColor.withOpacity(0.06);
    } else {
      bgColor = Colors.transparent;
    }

    // Determine icon and text color
    Color itemColor;
    if (isActive) {
      itemColor = primaryColor;
    } else if (widget.isLogout) {
      itemColor = _isHovered ? logoutColor : Colors.grey.shade500;
    } else {
      itemColor = _isHovered ? primaryColor : Colors.grey.shade500;
    }

    return MouseRegion(
      onEnter: (_) => setState(() => _isHovered = true),
      onExit: (_) => setState(() => _isHovered = false),
      cursor: SystemMouseCursors.click,
      child: GestureDetector(
        onTap: widget.onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            color: bgColor,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Row(
            children: [
              // Active indicator
              AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                width: 4,
                height: 20,
                margin: const EdgeInsets.only(right: 12),
                decoration: BoxDecoration(
                  color: isActive ? primaryColor : Colors.transparent,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              // Icon
              AnimatedDefaultTextStyle(
                duration: const Duration(milliseconds: 200),
                style: TextStyle(color: itemColor),
                child: Icon(
                  isActive ? widget.activeIcon : widget.icon,
                  size: 20,
                  color: itemColor,
                ),
              ),
              const SizedBox(width: 12),
              // Label
              AnimatedDefaultTextStyle(
                duration: const Duration(milliseconds: 200),
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: isActive ? FontWeight.w600 : FontWeight.w500,
                  color: itemColor,
                ),
                child: Text(widget.label),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
