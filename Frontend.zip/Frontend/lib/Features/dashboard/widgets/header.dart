import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class DashboardHeader extends StatelessWidget {
  final Function(String) onSearch;
  final VoidCallback? onSearchTap;
  final VoidCallback? onMenuTap;
  final bool readOnlySearch;
  final FocusNode? focusNode;

  const DashboardHeader({
    super.key,
    required this.onSearch,
    this.onSearchTap,
    this.onMenuTap,
    this.readOnlySearch = false,
    this.focusNode,
  });

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final dateFormatter = DateFormat('h:mm a dd MMM yyyy');
    final formattedDate = dateFormatter.format(now);
    final isNarrow = MediaQuery.of(context).size.width < 600;
    final padding = isNarrow
        ? const EdgeInsets.symmetric(horizontal: 12, vertical: 12)
        : const EdgeInsets.symmetric(horizontal: 24, vertical: 16);

    return Container(
      padding: padding,
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(
          bottom: BorderSide(
            color: Color(0xFFE5E7EB),
            width: 1,
          ),
        ),
      ),
      child: Row(
        children: [
          if (onMenuTap != null)
            Padding(
              padding: const EdgeInsets.only(right: 8),
              child: IconButton(
                onPressed: onMenuTap,
                icon: const Icon(Icons.menu_rounded),
                style: IconButton.styleFrom(
                  foregroundColor: const Color(0xFF1F2937),
                ),
              ),
            ),
          // Title + date - can shrink so search bar always fits
          Flexible(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Dashboard',
                  style: TextStyle(
                    fontSize: isNarrow ? 18 : 22,
                    fontWeight: FontWeight.bold,
                    color: const Color(0xFF1F2937),
                  ),
                  overflow: TextOverflow.ellipsis,
                  maxLines: 1,
                ),
                const SizedBox(height: 2),
                Text(
                  formattedDate,
                  style: TextStyle(
                    fontSize: isNarrow ? 11 : 13,
                    color: Colors.grey.shade500,
                  ),
                  overflow: TextOverflow.ellipsis,
                  maxLines: 1,
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          // Search bar - takes remaining space, min width so it never overflows
          Expanded(
            child: _SearchBar(
              onSearch: onSearch,
              onTap: onSearchTap,
              readOnly: readOnlySearch,
              focusNode: focusNode,
              compact: true,
            ),
          ),
        ],
      ),
    );
  }
}

class _SearchBar extends StatefulWidget {
  final Function(String) onSearch;
  final VoidCallback? onTap;
  final bool readOnly;
  final FocusNode? focusNode;
  final bool compact;

  const _SearchBar({
    required this.onSearch,
    this.onTap,
    this.readOnly = false,
    this.focusNode,
    this.compact = false,
  });

  @override
  State<_SearchBar> createState() => _SearchBarState();
}

class _SearchBarState extends State<_SearchBar> {
  final _controller = TextEditingController();
  bool _isFocused = false;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Background color changes on focus - same style as login input
    final bgColor = _isFocused 
        ? const Color(0xFFF0FDF4)  // Light green tint when focused
        : const Color(0xFFF5F5F5); // Light gray when not focused

    // When compact (always now - header is responsive), fill available width
    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      width: double.infinity,
      height: 40,
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        children: [
          Icon(
            Icons.search,
            color: _isFocused 
                ? const Color(0xFF00D26A) 
                : const Color(0xFF9CA3AF),
            size: 20,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Focus(
              onFocusChange: (hasFocus) {
                setState(() {
                  _isFocused = hasFocus;
                });
              },
              child: TextField(
                focusNode: widget.focusNode,
                controller: _controller,
                readOnly: widget.readOnly,
                onTap: widget.onTap,
                onChanged: widget.readOnly
                    ? null
                    : (value) {
                        setState(() {});
                        widget.onSearch(value);
                      },
                cursorColor: const Color(0xFF00D26A),
                style: const TextStyle(
                  fontSize: 14,
                  color: Color(0xFF374151),
                ),
                decoration: InputDecoration(
                  hintText: widget.readOnly ? 'Search (opens Violations)' : 'Search violations...',
                  hintStyle: const TextStyle(
                    fontSize: 14,
                    color: Color(0xFFB0B0B0),
                  ),
                  border: InputBorder.none,
                  enabledBorder: InputBorder.none,
                  focusedBorder: InputBorder.none,
                  filled: false,
                  isDense: true,
                  contentPadding: EdgeInsets.zero,
                ),
              ),
            ),
          ),
          if (!widget.readOnly && _controller.text.isNotEmpty)
            GestureDetector(
              onTap: () {
                _controller.clear();
                widget.onSearch('');
                setState(() {});
              },
              child: Padding(
                padding: const EdgeInsets.only(left: 8),
                child: Icon(
                  Icons.close,
                  color: _isFocused 
                      ? const Color(0xFF00D26A) 
                      : const Color(0xFF9CA3AF),
                  size: 18,
                ),
              ),
            ),
        ],
      ),
    );
  }
}
