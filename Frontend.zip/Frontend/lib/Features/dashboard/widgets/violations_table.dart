import 'package:flutter/material.dart';

class ViolationsTable extends StatefulWidget {
  final String searchQuery;

  const ViolationsTable({
    super.key,
    this.searchQuery = '',
  });

  @override
  State<ViolationsTable> createState() => _ViolationsTableState();
}

class _ViolationsTableState extends State<ViolationsTable> {
  int _currentPage = 1;
  final int _itemsPerPage = 10;

  // Sample violation data
  final List<ViolationData> _allViolations = [
    ViolationData(
      vehicleType: 'Sedan',
      plateNumber: '01 A 234 AB',
      location: 'Furkat Street, Tashkent',
      dateTime: DateTime(2026, 2, 2, 14, 23),
      status: 'Open',
    ),
    ViolationData(
      vehicleType: 'SUV',
      plateNumber: '10 Z 987 XY',
      location: 'Ring Road, Tashkent',
      dateTime: DateTime(2026, 2, 1, 9, 15),
      status: 'Reviewed',
    ),
    ViolationData(
      vehicleType: 'Taxi',
      plateNumber: '01 T 456 AA',
      location: 'Airport Highway, Tashkent',
      dateTime: DateTime(2026, 1, 30, 18, 40),
      status: 'Open',
    ),
    ViolationData(
      vehicleType: 'Truck',
      plateNumber: '80 K 112 BC',
      location: 'Industrial Zone, Tashkent',
      dateTime: DateTime(2026, 1, 29, 7, 5),
      status: 'Closed',
    ),
    ViolationData(
      vehicleType: 'Motorbike',
      plateNumber: '01 M 777 ZZ',
      location: 'City Center, Tashkent',
      dateTime: DateTime(2026, 1, 28, 21, 12),
      status: 'Open',
    ),
  ];

  List<ViolationData> get _filteredViolations {
    if (widget.searchQuery.isEmpty) {
      return _allViolations;
    }
    final query = widget.searchQuery.toLowerCase();
    return _allViolations.where((v) {
      return v.vehicleType.toLowerCase().contains(query) ||
          v.plateNumber.toLowerCase().contains(query) ||
          v.location.toLowerCase().contains(query) ||
          v.status.toLowerCase().contains(query);
    }).toList();
  }

  List<ViolationData> get _paginatedViolations {
    final startIndex = (_currentPage - 1) * _itemsPerPage;
    final endIndex = startIndex + _itemsPerPage;
    if (startIndex >= _filteredViolations.length) return [];
    return _filteredViolations.sublist(
      startIndex,
      endIndex > _filteredViolations.length ? _filteredViolations.length : endIndex,
    );
  }

  int get _totalPages {
    return (_filteredViolations.length / _itemsPerPage).ceil().clamp(1, 999);
  }

  static const double _narrowBreakpoint = 600;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final isNarrow = constraints.maxWidth < _narrowBreakpoint;
        final isInScrollView = constraints.maxHeight == double.infinity;
        final listHeight = isInScrollView ? 500.0 : null;

        if (isNarrow) {
          return _buildCardList(context, listHeight);
        }

        final tableBody = _paginatedViolations.isEmpty
            ? _buildEmptyState()
            : ListView.builder(
                itemCount: _paginatedViolations.length,
                itemBuilder: (context, index) {
                  final violation = _paginatedViolations[index];
                  return _ViolationRow(
                    data: violation,
                    onTap: () => _showViolationDetails(context, violation),
                  );
                },
              );

        final tableWidth = _tableMinWidth(constraints.maxWidth);
        final tableContent = SizedBox(
          width: tableWidth,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildHeaderRow(),
              if (listHeight != null)
                SizedBox(height: listHeight, child: tableBody)
              else
                Expanded(child: tableBody),
            ],
          ),
        );

        return SizedBox(
          width: double.infinity,
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.04),
                  blurRadius: 10,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                if (listHeight != null)
                  SizedBox(
                    height: listHeight,
                    child: SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: tableContent,
                    ),
                  )
                else
                  Expanded(
                    child: SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: tableContent,
                    ),
                  ),
                _buildFooter(constraints.maxWidth),
              ],
            ),
          ),
        );
      },
    );
  }

  double _tableMinWidth(double availableWidth) =>
      availableWidth > 700 ? availableWidth : 700;

  Widget _buildCardList(BuildContext context, double? listHeight) {
    final list = _paginatedViolations.isEmpty
        ? _buildEmptyState()
        : ListView.builder(
            shrinkWrap: listHeight == null,
            itemCount: _paginatedViolations.length,
            itemBuilder: (context, index) {
              final violation = _paginatedViolations[index];
              return _ViolationCard(
                data: violation,
                onTap: () => _showViolationDetails(context, violation),
              );
            },
          );

    return SizedBox(
      width: double.infinity,
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.04),
              blurRadius: 10,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
              child: Row(
                children: [
                  Text(
                    'Violations',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      color: Colors.grey.shade800,
                    ),
                  ),
                ],
              ),
            ),
            if (listHeight != null)
              SizedBox(height: listHeight, child: list)
            else
              Expanded(child: list),
            _buildFooter(300),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.warning_amber_rounded,
            size: 48,
            color: Colors.grey.shade300,
          ),
          const SizedBox(height: 16),
          Text(
            'No violations found',
            style: TextStyle(
              fontSize: 16,
              color: Colors.grey.shade500,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeaderRow() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: const BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color: Color(0xFFE5E7EB),
            width: 1,
          ),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            flex: 2,
            child: _headerText('Vehicle'),
          ),
          Expanded(
            flex: 2,
            child: _headerText('Plate number'),
          ),
          Expanded(
            flex: 3,
            child: _headerText('Location'),
          ),
          SizedBox(
            width: 110,
            child: _headerText('Date'),
          ),
          SizedBox(
            width: 80,
            child: _headerText('Time'),
          ),
          SizedBox(
            width: 90,
            child: _headerText('Status'),
          ),
        ],
      ),
    );
  }

  Widget _headerText(String text) {
    return Text(
      text,
      style: TextStyle(
        fontSize: 13,
        fontWeight: FontWeight.w600,
        color: Colors.grey.shade600,
      ),
    );
  }

  Widget _buildFooter(double width) {
    final startItem =
        _filteredViolations.isEmpty ? 0 : (_currentPage - 1) * _itemsPerPage + 1;
    final endItem = (_currentPage * _itemsPerPage).clamp(0, _filteredViolations.length);
    final narrow = width < 500;

    return Container(
      padding: EdgeInsets.symmetric(horizontal: narrow ? 12 : 20, vertical: narrow ? 12 : 16),
      decoration: const BoxDecoration(
        border: Border(
          top: BorderSide(
            color: Color(0xFFE5E7EB),
            width: 1,
          ),
        ),
      ),
      child: narrow
          ? Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  'Total: ${_filteredViolations.length} • $startItem-$endItem',
                  style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                ),
                const SizedBox(height: 8),
                _PaginationControls(
                  currentPage: _currentPage,
                  totalPages: _totalPages,
                  onPageChanged: (page) {
                    setState(() => _currentPage = page);
                  },
                ),
              ],
            )
          : Row(
              children: [
                Text(
                  'Total violations: ${_filteredViolations.length}',
                  style: TextStyle(fontSize: 14, color: Colors.grey.shade600),
                ),
                const Spacer(),
                Text(
                  '$startItem-$endItem of ${_filteredViolations.length} items',
                  style: TextStyle(fontSize: 13, color: Colors.grey.shade500),
                ),
                const SizedBox(width: 16),
                _PaginationControls(
                  currentPage: _currentPage,
                  totalPages: _totalPages,
                  onPageChanged: (page) {
                    setState(() => _currentPage = page);
                  },
                ),
              ],
            ),
    );
  }

  void _showViolationDetails(BuildContext context, ViolationData data) {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.45),
      builder: (context) {
        final dateStr =
            '${data.dateTime.day.toString().padLeft(2, '0')}.${data.dateTime.month.toString().padLeft(2, '0')}.${data.dateTime.year}';
        final timeStr =
            '${data.dateTime.hour.toString().padLeft(2, '0')}:${data.dateTime.minute.toString().padLeft(2, '0')}';

        return Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: const EdgeInsets.all(24),
          child: Container(
            width: 520,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.2),
                  blurRadius: 30,
                  offset: const Offset(0, 15),
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Header
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        Color(0xFF00D26A),
                        Color(0xFF00B85C),
                      ],
                    ),
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(20),
                      topRight: Radius.circular(20),
                    ),
                  ),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: const Icon(
                          Icons.local_police_outlined,
                          color: Color(0xFF00D26A),
                          size: 22,
                        ),
                      ),
                      const SizedBox(width: 14),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Violation',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            '$dateStr • $timeStr',
                            style: TextStyle(
                              fontSize: 13,
                              color: Colors.white.withOpacity(0.85),
                            ),
                          ),
                        ],
                      ),
                      const Spacer(),
                      _StatusChip(status: data.status),
                    ],
                  ),
                ),

                // Content
                Padding(
                  padding: const EdgeInsets.fromLTRB(24, 22, 24, 24),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: _InfoTile(
                              label: 'Vehicle type',
                              value: data.vehicleType,
                              icon: Icons.directions_car_outlined,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: _InfoTile(
                              label: 'Plate number',
                              value: data.plateNumber,
                              icon: Icons.confirmation_number_outlined,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      _InfoTile(
                        label: 'Location',
                        value: data.location,
                        icon: Icons.place_outlined,
                      ),
                      const SizedBox(height: 16),
                      _InfoTile(
                        label: 'Notes',
                        value:
                            'Vehicle detected violating traffic rules at the specified location. Please review dashcam footage for more details.',
                        icon: Icons.description_outlined,
                        multiLine: true,
                      ),
                      const SizedBox(height: 24),
                      Row(
                        children: [
                          Expanded(
                            child: _DialogButton(
                              label: 'Mark as reviewed',
                              icon: Icons.check_circle_outline,
                              color: const Color(0xFF00D26A),
                              onTap: () {
                                Navigator.of(context).pop();
                              },
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: _DialogButton(
                              label: 'Close',
                              icon: Icons.close,
                              color: Colors.grey.shade400,
                              isOutline: true,
                              onTap: () => Navigator.of(context).pop(),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

// Card widget for narrow screens
class _ViolationCard extends StatelessWidget {
  final ViolationData data;
  final VoidCallback onTap;

  const _ViolationCard({
    required this.data,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final date = data.dateTime;
    final dateStr =
        '${date.day.toString().padLeft(2, '0')}.${date.month.toString().padLeft(2, '0')}.${date.year}';
    final timeStr =
        '${date.hour.toString().padLeft(2, '0')}:${date.minute.toString().padLeft(2, '0')}';

    return Material(
      color: Colors.white,
      child: InkWell(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          decoration: const BoxDecoration(
            border: Border(
              bottom: BorderSide(color: Color(0xFFF3F4F6), width: 1),
            ),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  color: const Color(0xFFF3F4F6),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Icon(
                  Icons.directions_car_filled_outlined,
                  size: 18,
                  color: Color(0xFF6B7280),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      data.plateNumber,
                      style: const TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: Color(0xFF111827),
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      '${data.vehicleType} • ${data.location}',
                      style: TextStyle(
                        fontSize: 11,
                        color: Colors.grey.shade600,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '$dateStr $timeStr',
                      style: TextStyle(fontSize: 11, color: Colors.grey.shade500),
                    ),
                  ],
                ),
              ),
              _StatusChip(status: data.status),
            ],
          ),
        ),
      ),
    );
  }
}

// Row widget
class _ViolationRow extends StatefulWidget {
  final ViolationData data;
  final VoidCallback onTap;

  const _ViolationRow({
    required this.data,
    required this.onTap,
  });

  @override
  State<_ViolationRow> createState() => _ViolationRowState();
}

class _ViolationRowState extends State<_ViolationRow> {
  bool _isHovered = false;

  @override
  Widget build(BuildContext context) {
    final date = widget.data.dateTime;
    final dateStr =
        '${date.day.toString().padLeft(2, '0')}.${date.month.toString().padLeft(2, '0')}.${date.year}';
    final timeStr =
        '${date.hour.toString().padLeft(2, '0')}:${date.minute.toString().padLeft(2, '0')}';

    return MouseRegion(
      onEnter: (_) => setState(() => _isHovered = true),
      onExit: (_) => setState(() => _isHovered = false),
      cursor: SystemMouseCursors.click,
      child: GestureDetector(
        onTap: widget.onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 150),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            color: _isHovered ? const Color(0xFFF9FAFB) : Colors.white,
            border: const Border(
              bottom: BorderSide(
                color: Color(0xFFF3F4F6),
                width: 1,
              ),
            ),
          ),
          child: Row(
            children: [
              // Vehicle
              Expanded(
                flex: 2,
                child: Row(
                  children: [
                    Container(
                      width: 32,
                      height: 32,
                      decoration: BoxDecoration(
                        color: const Color(0xFFF3F4F6),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Icon(
                        Icons.directions_car_filled_outlined,
                        size: 18,
                        color: Color(0xFF6B7280),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        widget.data.vehicleType,
                        style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w500,
                          color: Color(0xFF111827),
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              ),
              // Plate
              Expanded(
                flex: 2,
                child: Text(
                  widget.data.plateNumber,
                  style: const TextStyle(
                    fontSize: 14,
                    color: Color(0xFF374151),
                  ),
                ),
              ),
              // Location
              Expanded(
                flex: 3,
                child: Text(
                  widget.data.location,
                  style: TextStyle(
                    fontSize: 13,
                    color: Colors.grey.shade600,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              // Date
              SizedBox(
                width: 110,
                child: Text(
                  dateStr,
                  style: const TextStyle(
                    fontSize: 13,
                    color: Color(0xFF374151),
                  ),
                ),
              ),
              // Time
              SizedBox(
                width: 80,
                child: Text(
                  timeStr,
                  style: const TextStyle(
                    fontSize: 13,
                    color: Color(0xFF374151),
                  ),
                ),
              ),
              // Status
              SizedBox(
                width: 90,
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: _StatusChip(status: widget.data.status),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// Pagination controls (same as before)
class _PaginationControls extends StatelessWidget {
  final int currentPage;
  final int totalPages;
  final Function(int) onPageChanged;

  const _PaginationControls({
    required this.currentPage,
    required this.totalPages,
    required this.onPageChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        _PageButton(
          icon: Icons.chevron_left,
          onTap: currentPage > 1 ? () => onPageChanged(currentPage - 1) : null,
        ),
        const SizedBox(width: 8),
        ...List.generate(totalPages.clamp(1, 5), (index) {
          final page = index + 1;
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 2),
            child: _PageNumberButton(
              page: page,
              isSelected: page == currentPage,
              onTap: () => onPageChanged(page),
            ),
          );
        }),
        const SizedBox(width: 8),
        _PageButton(
          icon: Icons.chevron_right,
          onTap: currentPage < totalPages
              ? () => onPageChanged(currentPage + 1)
              : null,
        ),
      ],
    );
  }
}

class _PageButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback? onTap;

  const _PageButton({
    required this.icon,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final isDisabled = onTap == null;

    return MouseRegion(
      cursor: isDisabled ? SystemMouseCursors.basic : SystemMouseCursors.click,
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          width: 32,
          height: 32,
          decoration: BoxDecoration(
            color: isDisabled ? Colors.grey.shade100 : Colors.white,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(
              color: const Color(0xFFE5E7EB),
            ),
          ),
          child: Icon(
            icon,
            size: 18,
            color: isDisabled ? Colors.grey.shade300 : Colors.grey.shade600,
          ),
        ),
      ),
    );
  }
}

class _PageNumberButton extends StatefulWidget {
  final int page;
  final bool isSelected;
  final VoidCallback onTap;

  const _PageNumberButton({
    required this.page,
    required this.isSelected,
    required this.onTap,
  });

  @override
  State<_PageNumberButton> createState() => _PageNumberButtonState();
}

class _PageNumberButtonState extends State<_PageNumberButton> {
  bool _isHovered = false;

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      onEnter: (_) => setState(() => _isHovered = true),
      onExit: (_) => setState(() => _isHovered = false),
      cursor: SystemMouseCursors.click,
      child: GestureDetector(
        onTap: widget.onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 150),
          width: 32,
          height: 32,
          decoration: BoxDecoration(
            color: widget.isSelected
                ? const Color(0xFF00D26A)
                : _isHovered
                    ? const Color(0xFFECFDF5)
                    : Colors.white,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(
              color: widget.isSelected
                  ? const Color(0xFF00D26A)
                  : _isHovered
                      ? const Color(0xFF00D26A).withOpacity(0.3)
                      : const Color(0xFFE5E7EB),
            ),
          ),
          child: Center(
            child: Text(
              widget.page.toString(),
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w500,
                color: widget.isSelected
                    ? Colors.white
                    : _isHovered
                        ? const Color(0xFF00D26A)
                        : Colors.grey.shade600,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// Simple status chip
class _StatusChip extends StatelessWidget {
  final String status;

  const _StatusChip({required this.status});

  @override
  Widget build(BuildContext context) {
    Color color;
    switch (status.toLowerCase()) {
      case 'open':
        color = const Color(0xFFEF4444);
        break;
      case 'reviewed':
        color = const Color(0xFFF59E0B);
        break;
      case 'closed':
        color = const Color(0xFF10B981);
        break;
      default:
        color = const Color(0xFF6B7280);
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        status,
        style: TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w500,
          color: color,
        ),
      ),
    );
  }
}

// Info tile used in dialog
class _InfoTile extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final bool multiLine;

  const _InfoTile({
    required this.label,
    required this.value,
    required this.icon,
    this.multiLine = false,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: const Color(0xFFF3F4F6),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(
            icon,
            size: 20,
            color: const Color(0xFF6B7280),
          ),
        ),
        const SizedBox(width: 14),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                  color: Color(0xFF9CA3AF),
                ),
              ),
              const SizedBox(height: 4),
              Text(
                value,
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                  color: Color(0xFF111827),
                ),
                maxLines: multiLine ? 3 : 1,
                overflow:
                    multiLine ? TextOverflow.visible : TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
      ],
    );
  }
}

// Button in dialog
class _DialogButton extends StatefulWidget {
  final String label;
  final IconData icon;
  final Color color;
  final bool isOutline;
  final VoidCallback onTap;

  const _DialogButton({
    required this.label,
    required this.icon,
    required this.color,
    this.isOutline = false,
    required this.onTap,
  });

  @override
  State<_DialogButton> createState() => _DialogButtonState();
}

class _DialogButtonState extends State<_DialogButton> {
  bool _isHovered = false;

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      onEnter: (_) => setState(() => _isHovered = true),
      onExit: (_) => setState(() => _isHovered = false),
      cursor: SystemMouseCursors.click,
      child: GestureDetector(
        onTap: widget.onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 150),
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: widget.isOutline
                ? (_isHovered ? widget.color.withOpacity(0.06) : Colors.white)
                : (_isHovered ? widget.color.withOpacity(0.9) : widget.color),
            borderRadius: BorderRadius.circular(12),
            border: widget.isOutline
                ? Border.all(color: widget.color, width: 1.5)
                : null,
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                widget.icon,
                size: 18,
                color: widget.isOutline ? widget.color : Colors.white,
              ),
              const SizedBox(width: 8),
              Text(
                widget.label,
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: widget.isOutline ? widget.color : Colors.white,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// Violation data model
class ViolationData {
  final String vehicleType;
  final String plateNumber;
  final String location;
  final DateTime dateTime;
  final String status;

  ViolationData({
    required this.vehicleType,
    required this.plateNumber,
    required this.location,
    required this.dateTime,
    required this.status,
  });
}

