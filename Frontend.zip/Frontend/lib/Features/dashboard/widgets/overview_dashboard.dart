import 'dart:math' as math;
import 'package:flutter/material.dart';

/// Dashboard overview (tab 0) — matches the "cards + big chart + lists" layout.
class DashboardOverviewContent extends StatelessWidget {
  const DashboardOverviewContent({super.key});

  static const double _narrowBreakpoint = 600;
  static const double _tinyBreakpoint = 400;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final w = constraints.maxWidth;
        final isNarrow = w < _narrowBreakpoint;
        final isTiny = w < _tinyBreakpoint;
        final padding = isTiny
            ? const EdgeInsets.fromLTRB(12, 12, 12, 16)
            : isNarrow
                ? const EdgeInsets.fromLTRB(16, 16, 16, 20)
                : const EdgeInsets.fromLTRB(24, 20, 24, 24);
        final gap = isTiny ? 10.0 : (isNarrow ? 12.0 : 16.0);

        Widget topCards;
        if (isTiny) {
          // Single column on tiny so each card gets full width and never overflows
          topCards = Column(
            mainAxisSize: MainAxisSize.min,
            children: const [
              _MiniStatCard(title: 'Total Violations', value: '654', trend: '+9.5%', trendUp: true, icon: Icons.warning_amber_rounded, accent: Color(0xFF00D26A)),
              SizedBox(height: 10),
              _MiniStatCard(title: 'Today', value: '18', trend: '+3.1%', trendUp: true, icon: Icons.today_rounded, accent: Color(0xFF7C3AED)),
              SizedBox(height: 10),
              _MiniStatCard(title: 'This Week', value: '96', trend: '-2.4%', trendUp: false, icon: Icons.date_range_rounded, accent: Color(0xFFF59E0B)),
              SizedBox(height: 10),
              _MiniStatCard(title: 'Resolved', value: '512', trend: '+7.2%', trendUp: true, icon: Icons.check_circle_rounded, accent: Color(0xFF3B82F6)),
            ],
          );
        } else if (isNarrow) {
          topCards = SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: const [
                SizedBox(width: 160, child: _MiniStatCard(title: 'Total Violations', value: '654', trend: '+9.5%', trendUp: true, icon: Icons.warning_amber_rounded, accent: Color(0xFF00D26A))),
                SizedBox(width: 12),
                SizedBox(width: 160, child: _MiniStatCard(title: 'Today', value: '18', trend: '+3.1%', trendUp: true, icon: Icons.today_rounded, accent: Color(0xFF7C3AED))),
                SizedBox(width: 12),
                SizedBox(width: 160, child: _MiniStatCard(title: 'This Week', value: '96', trend: '-2.4%', trendUp: false, icon: Icons.date_range_rounded, accent: Color(0xFFF59E0B))),
                SizedBox(width: 12),
                SizedBox(width: 160, child: _MiniStatCard(title: 'Resolved', value: '512', trend: '+7.2%', trendUp: true, icon: Icons.check_circle_rounded, accent: Color(0xFF3B82F6))),
              ],
            ),
          );
        } else {
          topCards = Row(
            children: const [
              Expanded(child: _MiniStatCard(title: 'Total Violations', value: '654', trend: '+9.5%', trendUp: true, icon: Icons.warning_amber_rounded, accent: Color(0xFF00D26A))),
              SizedBox(width: 16),
              Expanded(child: _MiniStatCard(title: 'Today', value: '18', trend: '+3.1%', trendUp: true, icon: Icons.today_rounded, accent: Color(0xFF7C3AED))),
              SizedBox(width: 16),
              Expanded(child: _MiniStatCard(title: 'This Week', value: '96', trend: '-2.4%', trendUp: false, icon: Icons.date_range_rounded, accent: Color(0xFFF59E0B))),
              SizedBox(width: 16),
              Expanded(child: _MiniStatCard(title: 'Resolved', value: '512', trend: '+7.2%', trendUp: true, icon: Icons.check_circle_rounded, accent: Color(0xFF3B82F6))),
            ],
          );
        }

        final middleSection = isNarrow
            ? Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const _OverviewChartCard(),
                  SizedBox(height: gap),
                  const _SummaryCard(),
                ],
              )
            : Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Expanded(flex: 7, child: _OverviewChartCard()),
                  SizedBox(width: gap),
                  const Expanded(flex: 3, child: _SummaryCard()),
                ],
              );

        final bottomSection = isNarrow
            ? Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const _RecentViolationsCard(),
                  SizedBox(height: gap),
                  const _SideMiniCards(),
                ],
              )
            : Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Expanded(flex: 7, child: _RecentViolationsCard()),
                  SizedBox(width: gap),
                  const Expanded(flex: 3, child: _SideMiniCards()),
                ],
              );

        return SingleChildScrollView(
          child: Padding(
            padding: padding,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                topCards,
                SizedBox(height: gap + 2),
                middleSection,
                SizedBox(height: gap + 2),
                bottomSection,
              ],
            ),
          ),
        );
      },
    );
  }
}

class _MiniStatCard extends StatelessWidget {
  final String title;
  final String value;
  final String trend;
  final bool trendUp;
  final IconData icon;
  final Color accent;

  const _MiniStatCard({
    required this.title,
    required this.value,
    required this.trend,
    required this.trendUp,
    required this.icon,
    required this.accent,
  });

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final w = constraints.maxWidth;
        final compact = w < 160;
        final veryNarrow = w < 100;
        final padding = veryNarrow ? 8.0 : (compact ? 10.0 : 16.0);
        final iconSize = veryNarrow ? 28.0 : (compact ? 32.0 : 38.0);
        final titleSize = veryNarrow ? 9.0 : (compact ? 10.0 : 12.0);
        final valueSize = veryNarrow ? 14.0 : (compact ? 16.0 : 20.0);
        final trendSize = veryNarrow ? 8.0 : (compact ? 9.0 : 11.0);

        return Container(
          height: veryNarrow ? 64 : (compact ? 76 : 92),
          padding: EdgeInsets.all(padding),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(compact ? 10 : 14),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.04),
                blurRadius: 12,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                width: iconSize,
                height: iconSize,
                decoration: BoxDecoration(
                  color: accent.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(compact ? 8 : 12),
                ),
                child: Icon(icon, color: accent, size: veryNarrow ? 14 : (compact ? 16 : 20)),
              ),
              SizedBox(width: veryNarrow ? 6 : (compact ? 8 : 14)),
              Expanded(
                child: LayoutBuilder(
                  builder: (context, innerConstraints) {
                    return Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          title,
                          style: TextStyle(
                            fontSize: titleSize,
                            color: Colors.grey.shade500,
                            fontWeight: FontWeight.w500,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        SizedBox(height: veryNarrow ? 1 : (compact ? 2 : 4)),
                        Row(
                          children: [
                            Flexible(
                              child: Text(
                                value,
                                style: TextStyle(
                                  fontSize: valueSize,
                                  fontWeight: FontWeight.w700,
                                  color: const Color(0xFF111827),
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            const SizedBox(width: 4),
                            Flexible(
                              fit: FlexFit.loose,
                              child: Container(
                                padding: EdgeInsets.symmetric(
                                  horizontal: veryNarrow ? 4 : (compact ? 6 : 10),
                                  vertical: veryNarrow ? 1 : (compact ? 2 : 4),
                                ),
                                decoration: BoxDecoration(
                                  color: (trendUp ? const Color(0xFF00D26A) : const Color(0xFFEF4444))
                                      .withOpacity(0.10),
                                  borderRadius: BorderRadius.circular(999),
                                ),
                                child: Text(
                                  trend,
                                  style: TextStyle(
                                    fontSize: trendSize,
                                    fontWeight: FontWeight.w600,
                                    color: trendUp ? const Color(0xFF00B85C) : const Color(0xFFEF4444),
                                  ),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    );
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _OverviewChartCard extends StatefulWidget {
  const _OverviewChartCard();

  @override
  State<_OverviewChartCard> createState() => _OverviewChartCardState();
}

class _OverviewChartCardState extends State<_OverviewChartCard> {
  int _rangeIndex = 0; // 0: ALL, 1: 1M, 2: 6M, 3: 1Y, 4: YTD

  @override
  Widget build(BuildContext context) {
    final isTiny = MediaQuery.of(context).size.width < 400;
    final height = isTiny ? 260.0 : 320.0;
    final padding = isTiny ? const EdgeInsets.fromLTRB(12, 12, 12, 10) : const EdgeInsets.fromLTRB(18, 16, 18, 14);
    return Container(
      height: height,
      padding: padding,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          LayoutBuilder(
            builder: (context, constraints) {
              final narrow = constraints.maxWidth < 400;
              return narrow
                  ? Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Text(
                          'Violations Overview',
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w700,
                            color: Color(0xFF111827),
                          ),
                        ),
                        const SizedBox(height: 8),
                        Wrap(
                          spacing: 6,
                          runSpacing: 6,
                          children: [
                            _RangeChip(label: 'ALL', selected: _rangeIndex == 0, onTap: () => setState(() => _rangeIndex = 0)),
                            _RangeChip(label: '1M', selected: _rangeIndex == 1, onTap: () => setState(() => _rangeIndex = 1)),
                            _RangeChip(label: '6M', selected: _rangeIndex == 2, onTap: () => setState(() => _rangeIndex = 2)),
                            _RangeChip(label: '1Y', selected: _rangeIndex == 3, onTap: () => setState(() => _rangeIndex = 3)),
                            _RangeChip(label: 'YTD', selected: _rangeIndex == 4, onTap: () => setState(() => _rangeIndex = 4)),
                          ],
                        ),
                      ],
                    )
                  : Row(
                      children: [
                        const Text(
                          'Violations Overview',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                            color: Color(0xFF111827),
                          ),
                        ),
                        const Spacer(),
                        _RangeChip(label: 'ALL', selected: _rangeIndex == 0, onTap: () => setState(() => _rangeIndex = 0)),
                        const SizedBox(width: 8),
                        _RangeChip(label: '1M', selected: _rangeIndex == 1, onTap: () => setState(() => _rangeIndex = 1)),
                        const SizedBox(width: 8),
                        _RangeChip(label: '6M', selected: _rangeIndex == 2, onTap: () => setState(() => _rangeIndex = 2)),
                        const SizedBox(width: 8),
                        _RangeChip(label: '1Y', selected: _rangeIndex == 3, onTap: () => setState(() => _rangeIndex = 3)),
                        const SizedBox(width: 8),
                        _RangeChip(label: 'YTD', selected: _rangeIndex == 4, onTap: () => setState(() => _rangeIndex = 4)),
                      ],
                    );
            },
          ),
          const SizedBox(height: 12),
          Expanded(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: CustomPaint(
                painter: _LineChartPainter(
                  lineColor: const Color(0xFF00D26A),
                  gridColor: const Color(0xFFE5E7EB),
                  points: _demoSeriesForRange(_rangeIndex),
                ),
                child: Container(),
              ),
            ),
          ),
          const SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: const [
              _LegendDot(color: Color(0xFF00D26A), label: 'Violations'),
            ],
          )
        ],
      ),
    );
  }

  List<double> _demoSeriesForRange(int idx) {
    // Simple fixed demo series shaped like the screenshot (smooth + dip + rise)
    final base = <double>[
      22, 30, 18, 26, 34, 28, 40, 24, 20, 29, 33, 27, 31, 29, 35, 30,
    ];
    if (idx == 0) return base;
    if (idx == 1) return base.sublist(base.length - 8);
    if (idx == 2) return base;
    if (idx == 3) return base;
    return base.sublist(2);
  }
}

class _RangeChip extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const _RangeChip({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      cursor: SystemMouseCursors.click,
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 150),
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          decoration: BoxDecoration(
            color: selected ? const Color(0xFF00D26A) : const Color(0xFFF5F5F5),
            borderRadius: BorderRadius.circular(999),
          ),
          child: Text(
            label,
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w600,
              color: selected ? Colors.white : const Color(0xFF6B7280),
            ),
          ),
        ),
      ),
    );
  }
}

class _LegendDot extends StatelessWidget {
  final Color color;
  final String label;

  const _LegendDot({required this.color, required this.label});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 8,
          height: 8,
          decoration: BoxDecoration(color: color, shape: BoxShape.circle),
        ),
        const SizedBox(width: 8),
        Text(
          label,
          style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
        )
      ],
    );
  }
}

class _LineChartPainter extends CustomPainter {
  final List<double> points;
  final Color lineColor;
  final Color gridColor;

  _LineChartPainter({
    required this.points,
    required this.lineColor,
    required this.gridColor,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final padding = const EdgeInsets.fromLTRB(8, 8, 8, 16);
    final w = size.width - padding.left - padding.right;
    final h = size.height - padding.top - padding.bottom;
    if (w <= 0 || h <= 0 || points.length < 2) return;

    final minV = points.reduce(math.min);
    final maxV = points.reduce(math.max);
    final range = (maxV - minV).abs() < 0.0001 ? 1.0 : (maxV - minV);

    // Grid
    final gridPaint = Paint()
      ..color = gridColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1;
    for (int i = 1; i <= 3; i++) {
      final y = padding.top + (h * i / 4);
      canvas.drawLine(Offset(padding.left, y), Offset(padding.left + w, y), gridPaint);
    }

    // Path
    final path = Path();
    for (int i = 0; i < points.length; i++) {
      final x = padding.left + (w * i / (points.length - 1));
      final norm = (points[i] - minV) / range;
      final y = padding.top + (h * (1 - norm));
      if (i == 0) {
        path.moveTo(x, y);
      } else {
        // Smooth cubic
        final prevX = padding.left + (w * (i - 1) / (points.length - 1));
        final prevNorm = (points[i - 1] - minV) / range;
        final prevY = padding.top + (h * (1 - prevNorm));
        final c1 = Offset(prevX + (x - prevX) * 0.5, prevY);
        final c2 = Offset(prevX + (x - prevX) * 0.5, y);
        path.cubicTo(c1.dx, c1.dy, c2.dx, c2.dy, x, y);
      }
    }

    // Fill under curve
    final fillPath = Path.from(path)
      ..lineTo(padding.left + w, padding.top + h)
      ..lineTo(padding.left, padding.top + h)
      ..close();
    final fillPaint = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          lineColor.withOpacity(0.22),
          lineColor.withOpacity(0.00),
        ],
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));
    canvas.drawPath(fillPath, fillPaint);

    // Stroke
    final strokePaint = Paint()
      ..color = lineColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.5
      ..strokeCap = StrokeCap.round;
    canvas.drawPath(path, strokePaint);

    // Marker dot on last point
    final lastX = padding.left + w;
    final lastNorm = (points.last - minV) / range;
    final lastY = padding.top + (h * (1 - lastNorm));
    canvas.drawCircle(Offset(lastX, lastY), 4.5, Paint()..color = lineColor);
    canvas.drawCircle(Offset(lastX, lastY), 8.5, Paint()..color = lineColor.withOpacity(0.12));
  }

  @override
  bool shouldRepaint(covariant _LineChartPainter oldDelegate) {
    return oldDelegate.points != points || oldDelegate.lineColor != lineColor;
  }
}

class _SummaryCard extends StatelessWidget {
  const _SummaryCard();

  @override
  Widget build(BuildContext context) {
    final isTiny = MediaQuery.of(context).size.width < 400;
    return Container(
      height: isTiny ? 260 : 320,
      padding: EdgeInsets.all(isTiny ? 12 : 18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  'Summary',
                  style: TextStyle(
                    fontSize: isTiny ? 14 : 16,
                    fontWeight: FontWeight.w700,
                    color: const Color(0xFF111827),
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              Container(
                width: isTiny ? 30 : 34,
                height: isTiny ? 30 : 34,
                decoration: BoxDecoration(
                  color: const Color(0xFFEEF2FF),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(Icons.add, size: isTiny ? 16 : 18, color: const Color(0xFF6366F1)),
              ),
            ],
          ),
          SizedBox(height: isTiny ? 12 : 16),
          _SummaryLine(
            label: 'Open',
            value: '142',
            color: const Color(0xFFEF4444),
          ),
          SizedBox(height: isTiny ? 8 : 10),
          _SummaryLine(
            label: 'Reviewed',
            value: '87',
            color: const Color(0xFFF59E0B),
          ),
          SizedBox(height: isTiny ? 8 : 10),
          _SummaryLine(
            label: 'Closed',
            value: '425',
            color: const Color(0xFF10B981),
          ),
          const Spacer(),
          Flexible(
            child: Container(
              constraints: const BoxConstraints(minHeight: 60),
              decoration: BoxDecoration(
                color: const Color(0xFFF8F9FA),
                borderRadius: BorderRadius.circular(14),
              ),
              child: const Center(
                child: Icon(
                  Icons.directions_car_filled_outlined,
                  size: 54,
                  color: Color(0xFFCBD5E1),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _SummaryLine extends StatelessWidget {
  final String label;
  final String value;
  final Color color;

  const _SummaryLine({
    required this.label,
    required this.value,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 10,
          height: 10,
          decoration: BoxDecoration(color: color, shape: BoxShape.circle),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Text(
            label,
            style: TextStyle(fontSize: 13, color: Colors.grey.shade600),
          ),
        ),
        Text(
          value,
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w700,
            color: Color(0xFF111827),
          ),
        )
      ],
    );
  }
}

class _RecentViolationsCard extends StatelessWidget {
  const _RecentViolationsCard();

  @override
  Widget build(BuildContext context) {
    final items = const [
      _RecentViolationRowData('01 A 234 AB', 'Furkat Street', '10:45 AM', 'Open'),
      _RecentViolationRowData('10 Z 987 XY', 'Ring Road', '09:15 AM', 'Reviewed'),
      _RecentViolationRowData('01 T 456 AA', 'Airport Highway', '08:01 AM', 'Open'),
      _RecentViolationRowData('80 K 112 BC', 'Industrial Zone', '07:05 AM', 'Closed'),
    ];

    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Recent Violations',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w700,
              color: Color(0xFF111827),
            ),
          ),
          const SizedBox(height: 14),
          ...items.map((e) => _RecentViolationRow(data: e)),
        ],
      ),
    );
  }
}

class _RecentViolationRowData {
  final String plate;
  final String location;
  final String time;
  final String status;

  const _RecentViolationRowData(this.plate, this.location, this.time, this.status);
}

class _RecentViolationRow extends StatelessWidget {
  final _RecentViolationRowData data;

  const _RecentViolationRow({required this.data});

  @override
  Widget build(BuildContext context) {
    Color statusColor;
    switch (data.status.toLowerCase()) {
      case 'open':
        statusColor = const Color(0xFFEF4444);
        break;
      case 'reviewed':
        statusColor = const Color(0xFFF59E0B);
        break;
      case 'closed':
        statusColor = const Color(0xFF10B981);
        break;
      default:
        statusColor = const Color(0xFF6B7280);
    }

    final narrow = MediaQuery.of(context).size.width < 400;
    final iconSize = narrow ? 28.0 : 34.0;
    final padding = narrow ? 8.0 : 12.0;

    return Container(
      padding: EdgeInsets.symmetric(vertical: padding),
      decoration: const BoxDecoration(
        border: Border(
          bottom: BorderSide(color: Color(0xFFF3F4F6), width: 1),
        ),
      ),
      child: Row(
        children: [
          Container(
            width: iconSize,
            height: iconSize,
            decoration: BoxDecoration(
              color: const Color(0xFFF3F4F6),
              borderRadius: BorderRadius.circular(narrow ? 8 : 10),
            ),
            child: Icon(Icons.directions_car_filled_outlined, size: narrow ? 14 : 18, color: const Color(0xFF6B7280)),
          ),
          SizedBox(width: narrow ? 8 : 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  data.plate,
                  style: TextStyle(
                    fontSize: narrow ? 11 : 13,
                    fontWeight: FontWeight.w600,
                    color: const Color(0xFF111827),
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                SizedBox(height: narrow ? 1 : 2),
                Text(
                  data.location,
                  style: TextStyle(fontSize: narrow ? 10 : 12, color: Colors.grey.shade500),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
          if (!narrow) ...[
            Text(
              data.time,
              style: TextStyle(fontSize: 12, color: Colors.grey.shade500),
            ),
            const SizedBox(width: 12),
          ],
          Container(
            padding: EdgeInsets.symmetric(horizontal: narrow ? 6 : 10, vertical: narrow ? 2 : 4),
            decoration: BoxDecoration(
              color: statusColor.withOpacity(0.10),
              borderRadius: BorderRadius.circular(999),
            ),
            child: Text(
              data.status,
              style: TextStyle(
                fontSize: narrow ? 9 : 11,
                fontWeight: FontWeight.w600,
                color: statusColor,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _SideMiniCards extends StatelessWidget {
  const _SideMiniCards();

  @override
  Widget build(BuildContext context) {
    return Column(
      children: const [
        _SmallInfoCard(
          title: 'System',
          subtitle: 'Monitoring active',
          icon: Icons.shield_outlined,
          accent: Color(0xFF00D26A),
        ),
        SizedBox(height: 16),
        _SmallInfoCard(
          title: 'Cameras',
          subtitle: '12 online',
          icon: Icons.videocam_outlined,
          accent: Color(0xFF6366F1),
        ),
      ],
    );
  }
}

class _SmallInfoCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final Color accent;

  const _SmallInfoCard({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.accent,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: accent.withOpacity(0.12),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: accent, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: Color(0xFF111827),
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  style: TextStyle(fontSize: 12, color: Colors.grey.shade500),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

