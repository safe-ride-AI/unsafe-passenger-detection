import 'package:flutter/material.dart';

class InputField extends StatefulWidget {
  final String hint;
  final IconData icon;
  final bool obscure;
  final TextEditingController? controller;

  const InputField({
    super.key,
    required this.hint,
    required this.icon,
    this.obscure = false,
    this.controller,
  });

  @override
  State<InputField> createState() => _InputFieldState();
}

class _InputFieldState extends State<InputField> {
  late bool _obscureText;
  bool _isFocused = false;

  @override
  void initState() {
    super.initState();
    _obscureText = widget.obscure;
  }

  @override
  Widget build(BuildContext context) {
    // Single consistent background color
    final bgColor = _isFocused 
        ? const Color(0xFFF0FDF4)  // Light green tint when focused
        : const Color(0xFFF5F5F5); // Light gray when not focused

    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      curve: Curves.easeOutCubic,
      height: 52,
      padding: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: _isFocused 
              ? const Color(0xFF00D26A).withOpacity(0.4)
              : const Color(0xFFE5E5E5),
          width: 1.5,
        ),
        boxShadow: _isFocused
            ? [
                BoxShadow(
                  color: const Color(0xFF00D26A).withOpacity(0.1),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ]
            : [],
      ),
      child: Row(
        children: [
          Icon(
            widget.icon, 
            color: _isFocused 
                ? const Color(0xFF00D26A) 
                : const Color(0xFF9CA3AF),
            size: 20,
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Focus(
              onFocusChange: (hasFocus) {
                setState(() {
                  _isFocused = hasFocus;
                });
              },
              child: TextField(
                controller: widget.controller,
                obscureText: _obscureText,
                cursorColor: const Color(0xFF00D26A),
                cursorWidth: 1.5,
                style: const TextStyle(
                  fontSize: 14,
                  color: Color(0xFF1F2937),
                  fontWeight: FontWeight.w400,
                ),
                decoration: InputDecoration(
                  border: InputBorder.none,
                  enabledBorder: InputBorder.none,
                  focusedBorder: InputBorder.none,
                  filled: false,
                  hintText: widget.hint,
                  hintStyle: const TextStyle(
                    color: Color(0xFFB0B0B0),
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                  ),
                  isDense: true,
                  contentPadding: EdgeInsets.zero,
                ),
              ),
            ),
          ),
          // Show hint as separate text when field is empty
          if (widget.obscure)
            GestureDetector(
              onTap: () {
                setState(() {
                  _obscureText = !_obscureText;
                });
              },
              child: Padding(
                padding: const EdgeInsets.only(left: 8),
                child: Icon(
                  _obscureText 
                      ? Icons.visibility_off_outlined 
                      : Icons.visibility_outlined,
                  color: _isFocused
                      ? const Color(0xFF00D26A)
                      : const Color(0xFF9CA3AF),
                  size: 20,
                ),
              ),
            ),
        ],
      ),
    );
  }
}
