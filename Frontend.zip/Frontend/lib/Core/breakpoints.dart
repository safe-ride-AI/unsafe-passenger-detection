class Breakpoints {
  static const double mobile = 600;
  static const double tablet = 1024;
}
