package com.example.safecommuteai

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
